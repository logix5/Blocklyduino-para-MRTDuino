#include "IOTMQTTClient.h"
#include <string.h>

void IOTMQTTClientInit(IOTMQTTClient* client, Network* network, const char* username, const char* password, const char* clientID, messageHandler defaultHandler)
{
	int i;
	MQTTClientInit(&client->mqttClient, network, 30000, client->sendbuf, IOT_MAX_MESSAGE_SIZE, client->readbuf, IOT_MAX_MESSAGE_SIZE, defaultHandler );

 	client->mqttClient.defaultMessageHandler = defaultHandler; //MQTTMessageArrived;
	client->username = username;
	client->password = password;
	client->clientID = clientID;
	
	
}

int IOTMQTTConnect(IOTMQTTClient* client)
{
	MQTTPacket_connectData data = MQTTPacket_connectData_initializer;
	data.MQTTVersion = 3;
	data.clientID.cstring = (char*)client->clientID;
	data.username.cstring = (char*)client->username;
	data.password.cstring = (char*)client->password;
	return MQTTConnect(&client->mqttClient, &data);
}

int IOTMQTTDisconnect(IOTMQTTClient* client)
{
	return MQTTDisconnect(&client->mqttClient);
}

int IOTMQTTConnected(IOTMQTTClient* client)
{
	return client->mqttClient.isconnected;
}

int IOTMQTTYield(IOTMQTTClient* client, int time)
{
	return MQTTYield(&client->mqttClient, time);
}
