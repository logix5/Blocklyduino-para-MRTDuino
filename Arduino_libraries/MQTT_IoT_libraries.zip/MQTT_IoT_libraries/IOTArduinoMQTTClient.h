#ifndef _IOTARDUINOMQTTCLIENT_h
#define _IOTARDUINOMQTTCLIENT_h

#include "IOTMQTTClient.h"

typedef void (*subscribeHandler)(void); 

const int MAX_CHANNEL_ARRAY_SIZE = 4;

class IOTArduinoMQTTClient
{
public:

	void begin(Client& _client, const char* _mqttserver, int _mqttport, const char* _username, const char* _password, const char* _clientID, int _chunkSize, messageHandler _mh, subscribeHandler _sH) 
	{
    m_connected=false;
    mqtt_subscriber=_sH;
    
    //strcpy(mqtt_server,_mqttserver);
    mqtt_server=_mqttserver;
    mqtt_port=_mqttport;
    
	Serial.println(_clientID);
		NetworkInit(&_network, &_client, _chunkSize);
		IOTMQTTClientInit(&_mqttClient, &_network, _username, _password, _clientID, _mh);
		Serial.println(_mqttserver);
		Serial.println(_mqttport);
		connect(_mqttserver,_mqttport);
	}

	void connect(const char* mqttserver,int mqttport) {

		Serial.println("Connecting to "+ String(mqttserver) +" :"+String(mqttport));
		int error = MQTT_FAILURE;
		do {
			if (!NetworkConnect(&_network, mqttserver, mqttport)) {
				
				Serial.println("Network connect failed");
				delay(1000);
			}
			else if ((error = IOTMQTTConnect(&_mqttClient)) != MQTT_SUCCESS) {
				
				Serial.println("MQTT connect failed, error "+String(error));
				NetworkDisconnect(&_network);
				delay(1000);
			}
		}
		while (error != MQTT_SUCCESS);

    if(mqtt_subscriber!=NULL)mqtt_subscriber();

    m_connected=true;

		Serial.println("Connected");
	}
 
	void loop(int yieldTime = 1000) {

		IOTMQTTYield(&_mqttClient, yieldTime);
  
		if (!NetworkConnected(&_network) || !IOTMQTTConnected(&_mqttClient))
		{
      m_connected=false;

			IOTMQTTDisconnect(&_mqttClient);
			NetworkDisconnect(&_network);
			Serial.println("Disconnected");

			connect(mqtt_server,mqtt_port);
		}
	}

  bool isConnected(){
    return m_connected;  
  }
  
  void Publish(String _topic, String _value){

      MQTTMessage message;
      message.qos = QOS0;
      message.retained = 1;
      message.dup = 0;
      message.payload = (void*)_value.c_str(); 
      message.payloadlen = strlen(_value.c_str());
      
      int result = MQTTPublish(&_mqttClient.mqttClient, _topic.c_str(), &message);       
  }

 void Subscribe(String _topic){

      int result=MQTTSubscribe(&_mqttClient.mqttClient, _topic.c_str(), QOS0, NULL); 
 }

  subscribeHandler mqtt_subscriber;

	static IOTMQTTClient _mqttClient;
	Network _network;

  const char* mqtt_server;
  int mqtt_port;  
  bool m_connected;
};

IOTMQTTClient IOTArduinoMQTTClient::_mqttClient;

#endif
