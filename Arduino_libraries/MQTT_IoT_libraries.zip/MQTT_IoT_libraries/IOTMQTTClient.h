#ifndef _IOTMQTTCLIENT_h
#define _IOTMQTTCLIENT_h

#include "MQTTClient.h"


#if defined(__cplusplus)
extern "C" {
#endif

#if defined(WIN32_DLL) || defined(WIN64_DLL)
  #define DLLImport __declspec(dllimport)
  #define DLLExport __declspec(dllexport)
#elif defined(LINUX_SO)
  #define DLLImport extern
  #define DLLExport  __attribute__ ((visibility ("default")))
#else
  #define DLLImport
  #define DLLExport
#endif

#ifndef IOT_MAX_MESSAGE_SIZE
#define IOT_MAX_MESSAGE_SIZE 134 
#endif

	typedef struct IOTMQTTClient
	{
		MQTTClient mqttClient; 
		const char* username;
		const char* password; 
		const char* clientID; 
		unsigned char sendbuf[IOT_MAX_MESSAGE_SIZE + 1]; /**< Buffer used for sending data. */
		unsigned char readbuf[IOT_MAX_MESSAGE_SIZE + 1]; /**< Buffer used for receiving data. */
    
	} IOTMQTTClient;

	DLLExport void IOTMQTTClientInit(IOTMQTTClient* client, Network* network, const char* username, const char* password, const char* clientID, messageHandler _mh); 

	DLLExport int IOTMQTTConnect(IOTMQTTClient* client);

	DLLExport int IOTMQTTDisconnect(IOTMQTTClient* client);
 
	DLLExport int IOTMQTTConnected(IOTMQTTClient* client);

	DLLExport int IOTMQTTYield(IOTMQTTClient* client, int time);

#if defined(__cplusplus)
   }
#endif

#endif
