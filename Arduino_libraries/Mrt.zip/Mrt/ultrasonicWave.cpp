/**
 * @file     ultrasonicWave.cpp
 * @version  v0.4.2
 * @date     2017.04.11
 * @details  초음파센서 거리 측정 (HC-SR04모듈)
 *
 */

#include "ultrasonicWave.h"

ultrasonicWave::ultrasonicWave() {}

/**
 * @brief       초음파센서 포트 초기화
 *
 * @param       int8_t trig_port   : trig 포트
 * @param       int8_t echo_port   : echo 포트
 */
ultrasonicWave::ultrasonicWave(int8_t trig_port, int8_t echo_port) {
    initUltrasonicPin(trig_port, echo_port);
}

/**
 * @brief       초음파센서 포트 초기화
 *
 * @param       int8_t trig_port   : trig 포트
 * @param       int8_t echo_port   : echo 포트
 */
void ultrasonicWave::initUltrasonic(int8_t trig_port, int8_t echo_port)
{
    _trigPin = convertPinNumberInt(trig_port);
    _echoPin = convertPinNumberInt(echo_port);

    pinMode(_trigPin, OUTPUT);
    pinMode(_echoPin, INPUT);
}

/**
 * @brief       초음파센서 포트 초기화 (for pin)
 *
 * @param       int trigPin   : trig pin
 * @param       int echoPin   : echo pin
 */
void ultrasonicWave::initUltrasonicPin(int trigPin, int echoPin) {
    _trigPin = trigPin;
    _echoPin = echoPin;

    pinMode(_trigPin, OUTPUT);
    pinMode(_echoPin, INPUT);
}

/**
 * @brief       초음파센서 포트 초기화, shield board
 *
 */
void ultrasonicWave::initUltrasonic(void) {
    initUltrasonicPin(A0, 13);
}

/**
 * @brief       거리 측정
 *
 * @return      long distance  : 측정된 거리 값( cm )
 */
long ultrasonicWave::checkDistance(void)
{
    long duration, distance;

    SoftPWMDisable();    

    digitalWrite(_trigPin, HIGH);
    delayMicroseconds(10);
    digitalWrite(_trigPin, LOW);

    distance = pulseIn(_echoPin, HIGH) * 17 / 1000;
    SoftPWMEnable();    // softPWM enable

    return distance;
}

/**
 * @brief       거리 측정, shield board
 *
 * @return      long distance  : 측정된 거리 값( cm )
 */
float ultrasonicWave::getDistance(void) {
    long duration;
    float distance;

    TIMSK1 = 0;          //  disable
    SoftPWMDisable();    //  disable

    digitalWrite(_echoPin, LOW);
    digitalWrite(_trigPin, LOW);
    delayMicroseconds(2);
    digitalWrite(_trigPin, HIGH);
    delayMicroseconds(10); // using IO trigger for at least 10us high level signal
    digitalWrite(_trigPin, LOW);

    duration = pulseIn(_echoPin, HIGH);

    distance = duration*((float)1/1000)*17;

    SoftPWMEnable();        // softPWM enable
    TIMSK1 = _BV(OCIE1A);   // ir remote timer1 enable

    delay(100);         // over 60ms

    return distance;
}
