/**
   @file    :   MrtColor.cpp
   @version :   v1.3.0
   @date    :   2018.05.04
   @details :   컬러센서 제어 \n
                out_port는 PORT 13 ~ PORT 16만 가능 (외부인터럽트 사용) \n
                S2,S3(LOW,LOW)   -> RED \n
                S2,S3(HIGH, HIGH)-> GREEN \n
                S2,S3(LOW, HIGH) -> BLUE \n
                S2,S3(HIGH, LOW) -> No filter
*/
#include "MrtColor.h"

MrtColorSensor::MrtColorSensor() {};

void MrtColorSensor::initColorSensorPin()
{
  pinMode(A3, OUTPUT);
  pinMode(A2, OUTPUT);
  pinMode(A1, INPUT);
}

void MrtColorSensor::colorDisable()
{
  digitalWrite(A3, HIGH);
  digitalWrite(A2, LOW);
}

int MrtColorSensor::getColor(int color)
{

  if (color == 1) {
    redColor = 0;
    for (int i = 0; i < 10; i++) {
      if(i > 2) {
      digitalWrite(A3, LOW);
      digitalWrite(A2, LOW);
      redFrequency = pulseIn(A1, LOW);
      redColor += redFrequency;
      }
    }
    returnValue = redColor * 1.1;
  }

  // green
  if (color == 2) {
    greenColor = 0;
    for (int i = 0; i < 10; i++) {
      if(i > 2) {
      digitalWrite(A3, HIGH);
      digitalWrite(A2, HIGH);
      greenFrequency = pulseIn(A1, LOW);
      greenColor += greenFrequency;
      }
    }
    returnValue = greenColor * 0.85;
  }
  // blue
  if (color == 3) {
    blueColor = 0;
    for (int i = 0; i < 10; i++) {
      if(i > 2) {
      digitalWrite(A3, LOW);
      digitalWrite(A2, HIGH);
      blueFrequency = pulseIn(A1, LOW);
      blueColor += blueFrequency;
      }
    }
    returnValue = blueColor * 1.1;
  }
  return returnValue;
}

