#ifndef _LCD1602_H_
#define _LCD1602_H_
#include "LiquidCrystal_I2C.h"

void Lcd1602_Init(void);


void Clear_(void);


void show(uint8_t Line,uint8_t Col,char * string);
void show(uint8_t Line,uint8_t Col,uint32_t number);



#endif
