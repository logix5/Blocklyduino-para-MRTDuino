/**
 * @file     :   MrtCommon.cpp
 * @version  :   v0.4.0
 * @date     :   2017.08.18
 * @details 공통함수
 */
#include <Arduino.h>

/**
 * @brief  Duino Port 번호를 프로그램에서 사용할 pin 번호로 변경
 * @param  int8_t   iopin     :  포트 번호 (input1 -> 1.. input8->8.. output1->9.. output8->16)
 * @return uint8_t  pinno     :  핀번호
 *    예) input1의 경우 1이 입력되면 13번 넘겨줌. \n
 *        input2의 경우 2      "     15  " \n
 *        .... \n
 *        17 ~ 20 dc 모터의 포트정의 \n
 *        (ML1:7,3   MR1:4,2 \n
 *         ML2:8,1   MR2:6,0)
 */
uint8_t convertPinNumberInt(int8_t iopin)
{
  int8_t pinno=-1;
  int8_t duino_pindef[]={13,15,16,14,18,19,20,21,5,9,11,12,2,3,0,1,7,4,8,6};

  if(iopin <= 20) pinno = duino_pindef[iopin-1];
  else pinno = 0xff;
  return pinno;
}

/** @brief disable I2C, gyro와 pwm 충돌
 *
 */
void disableI2C(void) {

    uint8_t twstoVal = (TWCR >> 4) & 0x01; 

    // TWSTO = 1, TWI stop condition
    if (twstoVal == 0) {
        
        TWCR = _BV(TWSTO); // no interrupts, Set Stop(release buss), disable TWI interface

        pinMode(2,INPUT);
        pinMode(3,INPUT);
        
    }
}

void enableI2C(void) {
    TWCR &= (0 << TWSTO);
    
}
