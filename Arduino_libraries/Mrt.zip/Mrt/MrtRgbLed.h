/**
 * @file     :   MrtRgbLed.h
 * @version  :   v0.4.1
 * @date     :   2017.08.14
 * @details  :   RGB Led 제어
 */

#ifndef MRT_RGB_LED_H
#define MRT_RGB_LED_H

#include <Arduino.h>
#include "MrtCommon.h"
#include "SoftPWM.h"

 class MrtRgbLed {
 public:
    MrtRgbLed();

    /**
     * @brief       RGB Led 포트 초기화
     *
     * @param       int8_t red_port    : red 값 지정 포트
     * @param       int8_t green_port  : green 값 지정 포트
     * @param       int8_t blue_port   : blue 값 지정 포트
     */
    MrtRgbLed(int8_t red_port, int8_t green_port, int8_t blue_port);

    /**
     * @brief       RGB Led 포트 초기화
     *
     * @param       int8_t red_port    : red 값 지정 포트
     * @param       int8_t green_port  : green 값 지정 포트
     * @param       int8_t blue_port   : blue 값 지정 포트
     */
    void initRgbLed(int8_t red_port, int8_t green_port, int8_t blue_port);

    /**
     * @brief   initialize RGB Led with shield board
     *
     */
    void initRgbLed();

    /**
     * @brief       색상 표시
     *
     * @param       uint8_t red    : red 값
     * @param       uint8_t green  : green 값
     * @param       uint8_t blue   : blue 값
     */
    void setColor(uint8_t red, uint8_t green, uint8_t blue);

    /**
     * @brief       개별 색상 표시
     *
     * @param       uint8_t pin
     * @param       uint8_t val color value (0-255)
     */
    void setColorAt(uint8_t pin, uint8_t val);

 private:
    int8_t  _redPin   = -1;
    int8_t  _greenPin = -1;
    int8_t  _bluePin  = -1;
 };
 #endif // MRT_RGB_LED_H
