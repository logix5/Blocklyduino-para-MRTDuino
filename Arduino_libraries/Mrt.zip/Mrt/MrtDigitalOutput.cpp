/**
* @file     MrtDigitalOutput.cpp
* @version  v1.0.6
* @date     2018.02.23
* @details  일반적인 Digital Output 센서 처리 \n
*           Sensed    => HIGH \n
*           no-Sensed => LOW
*/
#include "MrtDigitalOutput.h"

MrtDigitalOutput::MrtDigitalOutput() {};

/**
 * @brief  센서 초기화
 *
 * @param   uint8_t port_no : 포트번호
 *
 */
MrtDigitalOutput::MrtDigitalOutput(int8_t port_no) {
    initDigitalOutput(port_no);
}

/**
 * @brief  센서 초기화
 *
 * @param   uint8_t port_no : 포트번호
 *
 */
void MrtDigitalOutput::initDigitalOutput(int8_t port_no) {
    
    if ((port_no == 13) || (port_no == 14)) disableI2C();

    _pinNo = convertPinNumberInt(port_no);
    pinMode(_pinNo, OUTPUT);
}

/**
 * @brief  센서 ON
 */
void MrtDigitalOutput::sensorOn()
{
    digitalWrite(_pinNo, DIGITAL_OUTPUT_ON);
}

/**
 * @brief  센서 OFF
 */
void MrtDigitalOutput::sensorOff()
{
    digitalWrite(_pinNo, DIGITAL_OUTPUT_OFF);
}

/**
 * @brief   센서 ON/OFF
 *
 * @param   int flag    : on(1)/off(0) 스위치
 */
void MrtDigitalOutput::runSensor(int flag)
{
    if( flag == 0)  sensorOff();
    else            sensorOn();
}
