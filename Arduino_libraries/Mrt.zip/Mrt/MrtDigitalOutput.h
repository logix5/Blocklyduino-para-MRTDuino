/**
* @file     MrtDigitalOutput.h
* @version  v0.2.0
* @date     2016.09.22
* @details  일반적인 Digital Output 센서 처리 \n
*           Sensed    => HIGH \n
*           no-Sensed => LOW
*/
#include "MrtCommon.h"


#ifndef MRT_DIGITAL_OUTPUT_H
#define MRT_DIGITAL_OUTPUT_H

#define DIGITAL_OUTPUT_ON   HIGH
#define DIGITAL_OUTPUT_OFF  LOW

class MrtDigitalOutput {
public:
    MrtDigitalOutput();

    /**
     * @brief  센서 초기화
     *
     * @param   uint8_t port_no : 포트번호
     *
     */
    MrtDigitalOutput(int8_t port_no);

    /**
     * @brief  센서 초기화
     *
     * @param   uint8_t port_no : 포트번호
     *
     */
    void initDigitalOutput(int8_t port_no);
    /**
     * @brief  센서 ON
     */
    void sensorOn();
    /**
     * @brief  센서 OFF
     */
    void sensorOff();
    /**
     * @brief   센서 ON/OFF
     *
     * @param   int flag    : on(1)/off(0) 스위치
     */
    void runSensor(int flag);
    
private:
    int8_t      _pinNo;

};

#endif // MRT_DIGITAL_OUTPUT_H


