/*************************************************************************
* File Name          : MrtIdSetting.h
* Author             : Steve
* Updated            : Steve
* Version            : V1.0000
* Date               : 02/24/2016
* Description        : MRT Board ID Setting for IR Receiver Driver.
* License            : Solbea
* Copyright (C) 2014 - 2016 Solbea Ltd. All right reserved.
* steve at solbea dot com
**************************************************************************/
/**
* @date     2016.12.26
* @details  MRT IR receiver ID 값 읽기 \n
*           modified ReadId() - add sampling parameter
*/
#ifndef MrtIdSetting_h
#define MrtIdSetting_h

class MrtIdSetting{
	public:
	/**
     * @brief   constructor
     */
	MrtIdSetting();
	/**
     * @brief   constructor
     * @param   int sampling  :  반복횟수
     */
	MrtIdSetting(int sampling);

    /**
     * @brief   IR Receiver ID 값 읽기 (보드에 dip switch로 설정)
     *
     * @param   int sampling    체크횟수 (정확도위해), default 10
     * @return  int id          보드에 설정된 ID값
     * @details get much precise value, collect 10 times values. (default)
    */
    int ReadId(int sampling=10);

	/**
	 * @brief   보드의 START버튼이 눌렸는지 체크
	 *
	 * @param   int    flag : 눌림(1)/해제(0), default 1, pressed
	 * @return  bool   true : flag가 1이고, start버튼이 눌렸을 때 \n
	 *                        flag가 0이고, start버튼이 해제되었을 때 \n
	 *                false : flag가 1이고, start버튼이 해제되었을 때 \n
	 *                        flag가 0이고, start버튼이 눌렸을 때
	 */
    bool isStartPressed(int flag=1);

	private:
	bool dipswpin1, dipswpin2, dipswpin3;
	int sampling;
};
#endif //MrtIdSetting_h
